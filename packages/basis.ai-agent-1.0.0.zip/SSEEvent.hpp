// Copyright (C) 2026 Petr Mironychev
// SPDX-License-Identifier: MIT

#pragma once

#include <QByteArray>
#include <QString>



namespace LLMQore {

struct SSEEvent
{
    QString type;
    QByteArray data;
    QByteArray id;
};

} // namespace LLMQore
