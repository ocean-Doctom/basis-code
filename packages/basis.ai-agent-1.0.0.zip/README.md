# AI Agent

统一管理 AI 账户、API Key、模型与 Chat / Agent 对话。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
