#pragma once
#include <QWidget>
#include <memory>
#include <functional>
class ChatGptPage : public QWidget {
  public:
    explicit ChatGptPage(QWidget *parent = nullptr, const QString &provider = "chatgpt", bool autoLoadModels = true);
    ~ChatGptPage() override;
    void setComposerText(const QString &text);
    void setWorkspaceResolver(std::function<QString()> resolver);
    void setSettingsHandler(std::function<void()> handler);
    bool isBusy() const;
    static QWidget *createSettingsPage(QWidget *parent, std::function<void(QString)> openChat);
  private:
    friend struct ChatPageTestAccess;
    struct State;
    std::unique_ptr<State> state;
};
