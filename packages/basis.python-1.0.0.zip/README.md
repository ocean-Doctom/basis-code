# Python

配置 Python、运行与 PDB 调试。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
