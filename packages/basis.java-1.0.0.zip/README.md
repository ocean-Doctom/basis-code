# Java

配置 JDK、编译运行与 JDB 调试。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
