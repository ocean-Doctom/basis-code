#pragma once
#include <QObject>
#include <QString>
#include <QPointer>
#include <QStringConverter>
class QDialog;
class QMainWindow;
class QProcess;
class QPlainTextEdit;
class QTabWidget;
class QLineEdit;
class QWidget;
class QListWidget;

class DevTools : public QObject {
    Q_OBJECT
  public:
    explicit DevTools(QMainWindow *window);
    ~DevTools() override;
    static QString dataRoot();
    static QString projectsRoot();
    static QString compilerPath();
    static bool initialize(QString *error = nullptr);
    static bool safeArchiveEntry(QString entry);
    static QString compilerForSource(const QString &cpp, const QString &source);
    void showStorage();
    QWidget *createToolchainPage(QWidget *parent, const QString &language);
    void showTerminal(const QString &project);
    static bool runnerInstalled(const QString &language);
    static bool installRunner(const QString &language);

    void showCompilers();
    void showRuntime(const QString &language);
    static QString runtimePath(const QString &language);
    bool busy() const;
    void buildAndRun(const QString &source, const QString &project, bool debug = false);
    void stop();
  signals:
    void toolchainRequested(const QString &language);
    void projectRequested(const QString &path);
    void activityChanged(bool busy);
    void executionFinished(int code);
    void diagnosticRequested(const QString &path, int line, int column);
  private:
    friend struct DevToolsTestAccess;
    void log(const QString &text);
    void readProcessOutput(bool standardError);
    void consumeProcessText(const QString &text, bool standardError);
    void flushDiagnostics();
    void runExecutable();
    void updateProblems(const QString &line);
    void refreshProblemsBadge();
    QMainWindow *window;
    QProcess *process;
    QPlainTextEdit *output;
    QLineEdit *input;
    QWidget *dock;
    QTabWidget *outputTabs;
    QWidget *terminal = nullptr;
    QListWidget *problemsList = nullptr;
    int problemCount = 0;
    QString stdoutDiagnostic, stderrDiagnostic;
    QStringDecoder stdoutDecoder{QStringDecoder::System}, stderrDecoder{QStringDecoder::System};
    QStringList launchArguments;
    bool debugging = false;
    QString activeLanguage;
    QString javaMainClass;
    QString executable;
    QString workingDirectory;
    QString toolBin;
    bool compiling = false;
    bool stopping = false;
};
