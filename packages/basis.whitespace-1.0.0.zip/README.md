# Whitespace Cleaner

清理行尾空白与多余空行。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
