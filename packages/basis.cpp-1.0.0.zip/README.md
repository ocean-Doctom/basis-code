# C/C++

配置 C/C++ 编译器与运行支持。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
