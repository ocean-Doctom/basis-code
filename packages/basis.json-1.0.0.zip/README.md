# JSON Tools

校验和格式化 JSON，支持撤销。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
