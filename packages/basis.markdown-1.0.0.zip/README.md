# Markdown Preview

实时预览 Markdown 文档。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
