# Find and Replace

文档查找与可撤销的批量替换。

Native package for Basis Code 1.7.0 or later.

The host supplies the native engine; this package activates it and includes its source.
